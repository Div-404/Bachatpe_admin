import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-header',

  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent implements OnInit {


  constructor(private router: Router) { }

  ngOnInit(): void {

  }

  logOut() {
    Swal.fire({
      title: "Are you sure?",
      text: "You want to Log out",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes!"
    }).then((result: any) => {
      if (result.isConfirmed) {
        this.router.navigateByUrl('login')
        localStorage.clear()
      }
    })
  }

}
