import { Component, OnInit,AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { SharedService } from '../../servies/shared/shared.service';
import { configComm } from '../serviceDrop';
import { ApiService } from '../../servies/api.service';
import { ToastrService } from 'ngx-toastr';
import { filter } from 'rxjs';
@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrl: './side-bar.component.scss'
})
export class SideBarComponent implements OnInit, AfterViewInit {
  navactive: any = ""

  execDetails: any
  loginId: any
  profileId: any= ''

  execPermissions: any
    Money: any = []
    Recharge: any = []
    Booking: any = []
    Utility: any = []
    Miscellaneous: any = []
    serviceDrop: any = configComm
    serviceType: any = ''
    sourceList: any= []
    selectedTab: string = '';

  addClass: boolean = false;
@ViewChild('itemE5') itemE5?: ElementRef<HTMLElement>; // Configuration
@ViewChild('itemE6') itemE6?: ElementRef<HTMLElement>; // Users
@ViewChild('itemE4') itemE4?: ElementRef<HTMLElement>; // Finance
@ViewChild('itemE7') itemE7?: ElementRef<HTMLElement>; // Transaction
@ViewChild('itemE3') itemE3?: ElementRef<HTMLElement>; // Executive
@ViewChild('itemE9') itemE9?: ElementRef<HTMLElement>; // Reports
  constructor(private router: Router, private share: SharedService, private shared: SharedService, private api:ApiService,
    private toster: ToastrService
  ) {
    this.share.activeClass$.subscribe((activeClass: string) => {
      this.activeTab = activeClass;
      console.log('this.navactive', this.activeTab);
    });
    
    shared.selectedPermission.subscribe({next: (res: any)=>{
      this.execPermissions= res
      if (!this.execPermissions || Object.keys(this.execPermissions).length === 0){
        this.execPermissions = JSON.parse(sessionStorage.getItem("execDetails") || '{}')
      }
      console.log("permissions from side bar>>>>>", this.execPermissions);
      
    }})

    // Initialize the active class when the component loads
    const currentActive = this.share.getSidebrActiveClass();
    if (currentActive) {
      this.activeTab = currentActive;
      console.log("currentActive", currentActive)
    }
  }
ngAfterViewInit(): void {
  // Initial restore after refresh
  setTimeout(() => {
    this.syncSidebarOpenStateFromActiveTab();
  });

  // Also keep sync on route changes
  this.router.events
    .pipe(filter((event:any) => event instanceof NavigationEnd))
    .subscribe(() => {
      // If activeTab is not set in some cases, derive from URL
      if (!this.activeTab) {
        this.activeTab = this.router.url.replace(/^\//, '');
      }
      this.syncSidebarOpenStateFromActiveTab();
    });
}
private syncSidebarOpenStateFromActiveTab(): void {
  const tab = (this.activeTab || this.router.url || '').replace(/^\//, '');

  // close all main nodes first
  this.closeAllMainMenus();

  // open the correct main node
  if (this.isConfigurationTab(tab)) {
    this.openMainMenu(this.itemE5);
  } else if (this.isUsersTab(tab)) {
    this.openMainMenu(this.itemE6);
  } else if (this.isFinanceTab(tab)) {
    this.openMainMenu(this.itemE4);
  } else if (this.isTransactionTab(tab)) {
    this.openMainMenu(this.itemE7);
  } else if (this.isExecutiveTab(tab)) {
    this.openMainMenu(this.itemE3);
  } else if (this.isReportsTab(tab)) {
    this.openMainMenu(this.itemE9);
  }

  // optional: auto-open nested sections based on active tab
  this.syncNestedTogglesFromActiveTab(tab);
}
private syncNestedTogglesFromActiveTab(tab: string): void {
  // Finance
  if (
    tab.startsWith('balance-container') ||
    tab.startsWith('credit-container') ||
    tab.startsWith('aeps-container')
  ) {
    this.isBalanceOpen = true;
    sessionStorage.setItem('isBalanceOpen', 'true');
  }

  if (tab.startsWith('bulk-upload') || tab.startsWith('bulk-history')) {
    this.isBulkBalanceOpen = true;
    sessionStorage.setItem('isBulkBalanceOpen', 'true');
  }

  // Transaction
  if (tab.startsWith('money-main') || tab.startsWith('money-transfer-overall')) {
    this.isMoneyTransferOpen = true;
    sessionStorage.setItem('isMoneyTransferOpen', 'true');
  }

  if (tab.startsWith('recharge-overall')) {
    this.isRechargeOpen = true;
    sessionStorage.setItem('isRechargeOpen', 'true');
  }

  if (tab.startsWith('booking-overall')) {
    this.isBookingOpen = true;
    sessionStorage.setItem('isBookingOpen', 'true');
  }

  if (tab.startsWith('utility-overall')) {
    this.isUtilityOpen = true;
    sessionStorage.setItem('isUtilityOpen', 'true');
  }

  if (tab.startsWith('misc-overall')) {
    this.isMiscOpen = true;
    sessionStorage.setItem('isMiscOpen', 'true');
  }

  // Reports
  if (
    tab.startsWith('user-main') ||
    tab.startsWith('user-reports') ||
    tab.startsWith('api-reports') ||
    tab.startsWith('service-reports')
  ) {
    this.isTransReportsOpen = true;
    sessionStorage.setItem('isTransReportsOpen', 'true');
  }

  if (
    tab.startsWith('user-deposit-reports') ||
    tab.startsWith('executive-deposit-reports') ||
    tab.startsWith('reportbalance-main')
  ) {
    this.isDepositReportsOpen = true;
    sessionStorage.setItem('isDepositReportsOpen', 'true');
  }

  if (
    tab.startsWith('reportcredit-main') ||
    tab.startsWith('report-overall')
  ) {
    this.isDepositReportsOpen2 = true;
    sessionStorage.setItem('isDepositReportsOpen2', 'true');
  }

  if (tab.startsWith('pref-creditmain')) {
    this.isPerformerOpen = true;
    sessionStorage.setItem('isPerformerOpen', 'true');
  }
}
private openMainMenu(itemRef?: ElementRef<HTMLElement>): void {
  if (!itemRef?.nativeElement) return;
  itemRef.nativeElement.classList.remove('closeMenu');
  itemRef.nativeElement.classList.add('showMenu');
}

private closeAllMainMenus(): void {
  const refs = [this.itemE5, this.itemE6, this.itemE4, this.itemE7, this.itemE3, this.itemE9];
  refs.forEach((ref) => {
    const el = ref?.nativeElement;
    if (!el) return;
    el.classList.remove('showMenu');
    el.classList.remove('closeMenu');
  });
}
private isConfigurationTab(tab: string): boolean {
  return [
    'services',
    'api-manage',
    'all-packages',
    'config-sittings',
    'package-lm-wk',
    'signup-kyc-subtype',
    'signup-kyc'
  ].some(x => tab.startsWith(x));
}

private isUsersTab(tab: string): boolean {
  return [
    'user-list',
    'master-dis',
    'distributor',
    'retailer'
  ].some(x => tab.startsWith(x));
}

private isFinanceTab(tab: string): boolean {
  return [
    'balance-container',
    'credit-container',
    'aeps-container',
    'bulk-upload',
    'bulk-history',
    'packages',
    'manage-bank',
    'deposit-request',
    'payment-by-manual'
  ].some(x => tab.startsWith(x));
}

private isTransactionTab(tab: string): boolean {
  return [
    'money-main',
    'money-transfer',
    'money-transfer-overall',
    'recharge-overall',
    'booking-overall',
    'utility-overall',
    'misc-overall'
  ].some(x => tab.startsWith(x));
}

private isExecutiveTab(tab: string): boolean {
  return ['tab', 'sub-tab', 'executive'].some(x => tab.startsWith(x));
}

private isReportsTab(tab: string): boolean {
  return [
    'user-main',
    'user-reports',
    'api-reports',
    'service-reports',
    'user-deposit-reports',
    'executive-deposit-reports',
    'tax',
    'reports-commission',
    'reportcredit-main',
    'report-overall',
    'reportbalance-main',
    'belance-overall',
    'penality-main',
    'reports-penality',
    'business-main',
    'pref-creditmain'
  ].some(x => tab.startsWith(x));
}
  ngOnInit(): void {
    this.getSource()
 this.PrefNumber= localStorage.getItem('PerfNumber')
     this.share.selectedTab$.subscribe(tab => {
    this.selectedTab = tab;
  });
    
    this.isBulkBalanceOpen = JSON.parse(sessionStorage.getItem('isBulkBalanceOpen') || 'false');
    this.isBalanceOpen = JSON.parse(sessionStorage.getItem('isBalanceOpen') || 'false');
    this.isDepositOpen = JSON.parse(sessionStorage.getItem('isDepositOpen') || 'false');
    this.isMoneyTransferOpen = JSON.parse(sessionStorage.getItem('isMoneyTransferOpen') || 'false');
    this.isRechargeOpen = JSON.parse(sessionStorage.getItem('isRechargeOpen') || 'false');
    this.isBookingOpen = JSON.parse(sessionStorage.getItem('isBookingOpen') || 'false');
    this.isUtilityOpen = JSON.parse(sessionStorage.getItem('isUtilityOpen') || 'false');
    this.isMiscOpen = JSON.parse(sessionStorage.getItem('isMiscOpen') || 'false');
    console.log("isBookingOpen ngOninit", this.isBookingOpen)
    const urlTab = this.router.url.replace(/^\//, '');
if (urlTab) {
  this.activeTab = urlTab;
  this.share.setSidebrActiveClass(urlTab);
}
  }

hasAccess(masterName: string, subMasterName: string): boolean {
  if (this.execPermissions.length === 0) {
    return true;
  }

  const master = this.execPermissions.find((m: any) => m.Master === masterName);

  if (!master) {
    return true;
  }

  const subMaster = master.SubMasters.find((s: any) => s.SubMaster === subMasterName);
  return subMaster?.Access === 1 ||  subMaster?.Access === undefined;
}


  dataStatus: boolean = false
  // showSubmenu(itemEl: HTMLElement) {
  //   itemEl.classList.toggle("showMenu");
  // }

  // showSubmenu2(itemE2: HTMLElement) {
  //   itemE2.classList.toggle("showMenu");
  // }

  // showSubmenu3(itemE3: HTMLElement) {
  //   itemE3.classList.toggle("showMenu");
  // }
  // showSubmenu4(itemE4: HTMLElement) {
  //   itemE4.classList.toggle("showMenu");
  // }

  showSubmenu(itemEl: HTMLElement) {
  const isAlreadyOpen = itemEl.classList.contains('showMenu');

  // close all main menus
  const allMainMenus = document.querySelectorAll('#nav-links > li.showMenu, #nav-links > li.closeMenu');
  allMainMenus.forEach((menu: Element) => {
    menu.classList.remove('showMenu');
    menu.classList.remove('closeMenu');
  });

  // if clicked menu was closed, open it
  if (!isAlreadyOpen) {
    itemEl.classList.add('showMenu');
  } else {
    itemEl.classList.add('closeMenu');
  }
}

  activeTab: any
  navigate(val: any) {
   localStorage.removeItem('PerfNumber')
    if (val == 'bulk-upload' || val == 'bulk-history') {
      this.activeTab = val
      this.router.navigateByUrl("/" + val)
      this.share.setSidebrActiveClass(val);
      // this.isDepositOpen =false
      // this.isBalanceOpen =false
    }
    else if (val == 'balance-container' || val == 'credit-container' || val == 'aeps-container' || val == 'aeps-ledger' || val == 'aeps-transaction' || val == 'credit-ledger' || val == 'credit-transaction' || val == 'wallet-and-ledger' || val == 'deposit-transaction') {
      this.activeTab = val
      this.router.navigateByUrl("/" + val)
      this.share.setSidebrActiveClass(val);
      // this.isBulkBalanceOpen = false;
      // this.isDepositOpen =false

    }
    else if (val == 'deposit-request' || val == 'payment-by-manual') {
      this.activeTab = val
      this.router.navigateByUrl("/" + val)
      this.share.setSidebrActiveClass(val);
      // this.isBulkBalanceOpen = false;
      // this.isBalanceOpen =false
    }
    else if (val == 'booking-overall') {
      this.activeTab = val
      this.router.navigateByUrl("/" + val)
      this.share.setSidebrActiveClass(val);
    }

    else {
      this.shared.setReportTab(this.profileId)
      this.activeTab = val
      console.log("here is val", val);
      // this.isBulkBalanceOpen = false;
      // this.isDepositOpen =false
      this.router.navigateByUrl("/" + val)
      this.share.setSidebrActiveClass(val);
    }
  }

  PrefNumber: any
// navigatePref(val: any, id: any) {
//   // console.log('here from side bar number>>>>>>>>>>>>>>>>>>>>>>>>>>>', localStorage.getItem('PerfNumber'));
//   this.activeTab = `${val}?id=${id}`;
//   this.router.navigateByUrl(`pref-creditmain/${val}?id=${id}`);
//   this.share.setSidebrActiveClass(`pref-creditmain/${val}`);
//   this.share.setSelectedTab(val);  // 👈 new line
//   this.share.setPref(id)
//   this.PrefNumber= id
// }

navigatePref(val: string, id: number) {
  // 🔴 Reset report-related states
  this.isTransReportsOpen = false;
  this.isDepositReportsOpen = false;
  this.isDepositReportsOpen2 = false;

  // ✅ Single source of truth
  this.activeTab = `pref-creditmain/${val}?id=${id}`;

  this.router.navigateByUrl(this.activeTab);
  this.share.setSidebrActiveClass(this.activeTab);

  this.isPerformerOpen = true;
}

  

// ============================================================ get source ===========================================================

getSource() {
  // alert("dfgfdhgfhgfjhgjg")
  this.Money = []
  this.Recharge = []
  this.Booking = []
  this.Utility = []
  this.Miscellaneous = []
  // this.shared.loader(true)
  this.api.getSource().subscribe({
    next: (res: any) => {
      // this.shared.loader(false)
      this.sourceList = res
      console.log("here is source list", this.sourceList);

      this.sourceList.forEach((ele: any) => {
        if (ele.Type == 1) {
          this.Money = ele.lstSource
          console.log("money list", this.Money);
        }
        else if (ele.Type == 2) {
          this.Recharge = ele.lstSource
          console.log("recharge list", this.Recharge);
        }
        else if (ele.Type == 3) {
          this.Booking = ele.lstSource
          console.log("Booking list", this.Booking);
        }
        else if (ele.Type == 4) {
          this.Utility = ele.lstSource
          console.log("Utility list", this.Utility);
        }
        else if (ele.Type == 5) {
          this.Miscellaneous = ele.lstSource
          console.log("Miscellaneous list", this.Miscellaneous);
        }

      });

    }, error: (err: any) => {
      this.shared.loader(false)
      this.toster.error("Something went wrong", "Error")

    }
  })
}

// =============================================================== change service type ===================================================

changeService(val: any) {
  this.share.setSideBarName(val.Source)
  console.log("here is val", val.SourceId, val);
  

}

  isBulkBalanceOpen: boolean = false;
  // toggleBulkBalance() {
  //   this.isBulkBalanceOpen = !this.isBulkBalanceOpen; // Toggle the boolean value
  // }
  isBalanceOpen: boolean = false;
  // toggleBalance() {
  //   this.isBalanceOpen = !this.isBalanceOpen; // Toggle the boolean value
  // }
  isDepositOpen = false; // To manage the toggle state for Deposit section

  // toggleDeposit() {
  //   this.isDepositOpen = !this.isDepositOpen; // Toggle the boolean value
  // }
  toggleBulkBalance() {
    this.isBulkBalanceOpen = !this.isBulkBalanceOpen; // Toggle the boolean value
    sessionStorage.setItem('isBulkBalanceOpen', JSON.stringify(this.isBulkBalanceOpen)); // Store the state in local storage
  }
  isMoneyTransferOpen: boolean = false
  toggleMoneyTransfer() {
    this.isMoneyTransferOpen = !this.isMoneyTransferOpen; // Toggle the boolean value
    sessionStorage.setItem('isMoneyTransferOpen', JSON.stringify(this.isMoneyTransferOpen)); // Store the state in local storage
  }
  toggleBalance() {
    this.isBalanceOpen = !this.isBalanceOpen; // Toggle the boolean value
    sessionStorage.setItem('isBalanceOpen', JSON.stringify(this.isBalanceOpen)); // Store the state in local storage
  }

  toggleDeposit() {
    this.isDepositOpen = !this.isDepositOpen; // Toggle the boolean value
    sessionStorage.setItem('isDepositOpen', JSON.stringify(this.isDepositOpen)); // Store the state in local storage
  }

  isRechargeOpen: boolean = false
  toggleRecharge() {
    this.isRechargeOpen = !this.isRechargeOpen; // Toggle the boolean value
    sessionStorage.setItem('isRechargeOpen', JSON.stringify(this.isRechargeOpen)); // Store the state in local storage
  }

  isBookingOpen: boolean = false
  toggleBooking() {
    this.isBookingOpen = !this.isBookingOpen; // Toggle the boolean value
    sessionStorage.setItem('isBookingOpen', JSON.stringify(this.isBookingOpen)); // Store the state in local storage
  }

  isUtilityOpen: boolean = false
  toggleUtility() {
    this.isUtilityOpen = !this.isUtilityOpen; // Toggle the boolean value
    sessionStorage.setItem('isUtilityOpen', JSON.stringify(this.isUtilityOpen)); // Store the state in local storage
  }

  isMiscOpen: boolean = false
  toggleMisc() {
    this.isMiscOpen = !this.isMiscOpen; // Toggle the boolean value
    sessionStorage.setItem('isMiscOpen', JSON.stringify(this.isMiscOpen)); // Store the state in local storage
  }
  isTransReportsOpen: boolean = false
  toggleTransReports() {
    this.isTransReportsOpen = !this.isTransReportsOpen; // Toggle the boolean value
    sessionStorage.setItem('isTransReportsOpen', JSON.stringify(this.isTransReportsOpen)); // Store the state in local storage
  }
  isDepositReportsOpen: boolean = false
  toggleDepositReports() {
    this.isDepositReportsOpen = !this.isDepositReportsOpen; // Toggle the boolean value
    sessionStorage.setItem('isDepositReportsOpen', JSON.stringify(this.isDepositReportsOpen)); // Store the state in local storage
  }

    isDepositReportsOpen2: boolean = false
  toggleDepositReports2() {
    this.isDepositReportsOpen2 = !this.isDepositReportsOpen2; // Toggle the boolean value
    sessionStorage.setItem('isDepositReportsOpen2', JSON.stringify(this.isDepositReportsOpen2)); // Store the state in local storage
  }

  isPerformerOpen: boolean = JSON.parse(sessionStorage.getItem('isPerformerOpen') || 'false');
  togglePerformer() {
    this.isPerformerOpen = !this.isPerformerOpen;
    sessionStorage.setItem('isPerformerOpen', JSON.stringify(this.isPerformerOpen));
  }
}
