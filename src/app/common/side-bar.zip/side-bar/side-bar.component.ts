import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { SharedService } from '../../servies/shared/shared.service';

@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',

  styleUrl: './side-bar.component.scss'
})
export class SideBarComponent implements OnInit{
navactive: any = ""
  execPermission: any
  execDetails: any
  loginId: any
 
  addClass: boolean = false;
  openSidebar: boolean = true;

  menuSidebar = [
    {
      link_name: 'Dashboard',
      link: '/user-list',
      icon: 'bx bx-grid-alt',
      sub_menu: [],
    },
    {
      link_name: 'Category',
      link: null,
      icon: 'bx bx-collection',
      sub_menu: [
        {
          link_name: 'HTML & CSS',
          link: '/html-n-css',
        },
        {
          link_name: 'JavaScript',
          link: '/javascript',
        },
        {
          link_name: 'PHP & MySQL',
          link: '/php-n-mysql',
        },
      ],
    },
    {
      link_name: 'Posts',
      link: null,
      icon: 'bx bx-book-alt',
      sub_menu: [
        {
          link_name: 'Web Design',
          link: '/posts/web-design',
        },
        {
          link_name: 'Login Form',
          link: '/posts/login-form',
        },
        {
          link_name: 'Card Design',
          link: '/posts/card-design',
        },
      ],
    },
    {
      link_name: 'Analytics',
      link: '/analytics',
      icon: 'bx bx-pie-chart-alt-2',
      sub_menu: [],
    },
    {
      link_name: 'Chart',
      link: '/chart',
      icon: 'bx bx-line-chart',
      sub_menu: [],
    },
    {
      link_name: 'Plugins',
      link: null,
      icon: 'bx bx-plug',
      sub_menu: [
        {
          link_name: 'UI Face',
          link: '/ui-face',
        },
        {
          link_name: 'Pigments',
          link: '/pigments',
        },
        {
          link_name: 'Box Icons',
          link: '/box-icons',
        },
      ],
    },
   
  ];
  constructor(private router:Router, private share:SharedService) {
    this.share.activeClass$.subscribe((res: any) => {

      this.navactive = res

      console.log(" this.navactive ", this.navactive)
    })
  }


  ngOnInit(): void {

  }
  showSubmenu(itemEl: HTMLElement) {
    itemEl.classList.toggle('showMenu');
  }

  dataStatus: boolean = false
  showSubmenu1(itemEl: HTMLElement) {
    itemEl.classList.toggle("showMenu");
  }

  showSubmenu2(itemE2: HTMLElement) {
    itemE2.classList.toggle("showMenu");
  }

  showSubmenu3(itemE3: HTMLElement) {
    itemE3.classList.toggle("showMenu");
  }
  showSubmenu4(itemE4: HTMLElement) {
    itemE4.classList.toggle("showMenu");
  }

  activeTab: any
  navigate(val: any) {
    if(val == 'bulk-upload' || val == 'bulk-history'){
      this.activeTab= val
      this.router.navigateByUrl("/" + val)
      this.isDepositOpen =false
    }
    else  if(val == 'deposit-request' || val == 'payment-by-manual'){
      this.activeTab= val
      this.router.navigateByUrl("/" + val)
      this.isBulkBalanceOpen = false;
    }
    else {
    this.activeTab= val
console.log("here is val", val);
this.isBulkBalanceOpen = false;
this.isDepositOpen =false
this.router.navigateByUrl("/" + val)
    }
  }

  isBulkBalanceOpen = false; 
  toggleBulkBalance() {
    this.isBulkBalanceOpen = !this.isBulkBalanceOpen; // Toggle the boolean value
  }
  isDepositOpen = false; // To manage the toggle state for Deposit section

  toggleDeposit() {
    this.isDepositOpen = !this.isDepositOpen; // Toggle the boolean value
  }
}
