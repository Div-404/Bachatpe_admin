import { Component, TemplateRef } from '@angular/core';

import { NgbDropdownModule, NgbModal, } from '@ng-bootstrap/ng-bootstrap';
import { NgbOffcanvas } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-user-package',
  standalone: true,
  imports: [NgbDropdownModule, CommonModule, NgMultiSelectDropDownModule, FormsModule],
  templateUrl: './user-package.component.html',
  styleUrl: './user-package.component.scss'
})
export class UserPackageComponent {

  dropdownList:any = [];
  selectedItems :any= [];
  dropdownSettings:any = {};
  items = Array(5).fill(0);
  constructor(private modalService: NgbModal, private offcanvasService:NgbOffcanvas, private router: Router){
    this.dropdownList = [
      { "item_id": 1, item_text: 'Mumbai' },
      { item_id: 2, item_text: 'Bangaluru' },
      { item_id: 3, item_text: 'Pune' },
      { item_id: 4, item_text: 'Navsari' },
      { item_id: 5, item_text: 'New Delhi' }
    ];
    this.selectedItems = [
      { item_id: 3, item_text: 'Pune' },
      { item_id: 4, item_text: 'Navsari' }
    ];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
  }

  openEnd(content: TemplateRef<any>) {
		this.offcanvasService.open(content, { position: 'end' });
	}
  openLg(content: TemplateRef<any>) {
		this.modalService.open(content, { size: 'md modalone', centered: true, windowClass: 'flip-modal' } );
	}

  navigate(val:any){
    this.router.navigateByUrl(val)
  }

  onSelectAll(ev:any){}
  onItemSelect(ev:any){}
}
