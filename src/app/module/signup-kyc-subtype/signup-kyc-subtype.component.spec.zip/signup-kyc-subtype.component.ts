// src/app/admin/signup-kyc-subtype/signup-kyc-subtype.component.ts
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';
import { CommonModule, DatePipe, formatDate } from '@angular/common';
import { SharedService } from '../../servies/shared/shared.service';
import { ApiService } from '../../servies/api.service';
import { ToastrService } from 'ngx-toastr';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonmoduleModule } from '../../common/commonmodule.module';

@Component({
  selector: 'app-signup-kyc-subtype',
  templateUrl: './signup-kyc-subtype.component.html',
    standalone: true,
    imports: [CommonModule, FormsModule, ReactiveFormsModule, CommonmoduleModule],
})
export class SignupKycSubtypeComponent implements OnInit {
  form: FormGroup;
  subtypes: any[] = [];
  loadingList = false;
  saving = false;

  constructor(
    private fb: FormBuilder,
    private api: ApiService
  ) {
    this.form = this.fb.group({
      stageId: [null, [Validators.required]],
      subType: ['', [Validators.required, Validators.maxLength(100)]],
      url: ['', [Validators.maxLength(500)]],
    });
  }

  ngOnInit(): void {}

  get f() {
    return this.form.controls;
  }

  /** When stage changes / blur, fetch subtypes for that stage */
  onStageChange(): void {
    const stageId = Number(this.f['stageId'].value);
    if (!stageId) {
      this.subtypes = [];
      return;
    }
    this.loadSubTypes(stageId);
  }

  private loadSubTypes(stageId: number): void {
    this.loadingList = true;
    this.api.getSubTypes(stageId).subscribe({
      next: (list) => {
        this.subtypes = Array.isArray(list) ? list : [];
        this.loadingList = false;
      },
      error: (err) => {
        console.error('GET_STAGE_SUB_TYPE error', err);
        this.subtypes = [];
        this.loadingList = false;
        Swal.fire('Error', 'Unable to load subtypes for this stage.', 'error');
      },
    });
  }

  /** Add / update subtype */
  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const stageId = Number(this.f['stageId'].value);
    const subType = (this.f['subType'].value || '').trim();
    const url = (this.f['url'].value || '').trim();

    this.saving = true;

    this.api.addSubtype(stageId, subType, url).subscribe({
      next: (res:any) => {
        this.saving = false;
        Swal.fire(
          'Success',
          res?.MSG_USER || 'Stage subtype modified successfully',
          'success'
        );

        // Clear only subtype + URL; keep Stage selected so user can add more
        this.f['subType'].reset('');
        this.f['url'].reset('');

        this.loadSubTypes(stageId);
      },
      error: (err) => {
        this.saving = false;
        console.error('ADD_STAGE_SUB_TYPE error', err);
        Swal.fire(
          'Error',
          err?.error?.MSG_USER || 'Failed to save stage subtype.',
          'error'
        );
      },
    });
  }

  /** SweetAlert2 confirmation before delete */
  confirmDelete(sub: any): void {
    const subTypeId = sub?.SubTypeID;
    const name = sub?.oSubType?.SubType || 'this subtype';

    Swal.fire({
      title: 'Delete subtype?',
      text: `Are you sure you want to delete "${name}"?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#d33',
    }).then((result) => {
      if (result.isConfirmed && subTypeId) {
        this.deleteSubtype(subTypeId);
      }
    });
  }

  private deleteSubtype(subTypeId: number): void {
    const stageId = Number(this.f['stageId'].value) || 0;

    this.api.deleteSubtype(subTypeId).subscribe({
      next: (res:any) => {
        Swal.fire(
          'Deleted',
          res?.MSG_USER || 'Stage subtype deleted successfully',
          'success'
        );
        if (stageId) {
          this.loadSubTypes(stageId);
        }
      },
      error: (err) => {
        console.error('DEL_STAGE_SUB_TYPE error', err);
        Swal.fire(
          'Error',
          err?.error?.MSG_USER || 'Failed to delete stage subtype.',
          'error'
        );
      },
    });
  }
}