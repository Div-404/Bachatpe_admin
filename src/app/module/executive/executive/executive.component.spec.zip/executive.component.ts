import { Component ,OnInit,ChangeDetectorRef} from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { GlobalAPIService } from './../../../service/global-api.service';
import { CookieService } from 'ngx-cookie-service';
import { SharedDataService } from 'src/app/service/shared-data.service';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';
import { FormBuilder, FormGroup, Validators ,FormArray} from '@angular/forms';
@Component({
  selector: 'app-executive',
  templateUrl: './executive.component.html',
  styleUrls: ['./executive.component.scss']
})
export class ExecutiveComponent implements OnInit{
  modref: any;
 execForm:any = FormGroup;
  masterData: any;
  subMasterData: any;
  getEditData:boolean=false;
  selectedSubMasterID: any;
  selectedMasterID: any;
  executiveData: any;
  masterList: any[] = []; 
  subMasterList: any[] = [];
  modalMasterList: any=[];
  modalSubMasterList: any=[];
  masterOptions: any;
  subMasterOptions: any=[];
  masterID: any;
  subMasterID: any;
  execID: any;
  
  constructor(private modalService: NgbModal,private cd :ChangeDetectorRef,private fb: FormBuilder,private shared:SharedDataService, private cookie: CookieService,  private api:GlobalAPIService,public toastrService:ToastrService) {}


  ngOnInit(): void {
    this.getExecutive();
    this.getModule();
    this.getSubMaster();
    this.execForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', Validators.required],
      phone: ['', Validators.required],
      country: ['', Validators.required],
      status: ['', Validators.required],
      lstPermit: this.fb.array([
        this.createModuleFormGroup(),
      ]),
    });
   
 
  }
  // <-- Form array for Executives (Start) --->
  createModuleFormGroup() {
    return this.fb.group({
      MasterID: ['',Validators.required],
      SubMasterID: ['',Validators.required],
     
    });
  }
  addModule() {
    const moduleGroup = this.createModuleFormGroup();
    (<FormArray>this.execForm.get('lstPermit')).push(moduleGroup);
  }
  
  removeModule(index: number) {
    (<FormArray>this.execForm.get('lstPermit')).removeAt(index);
  }

   // <-- Form array for Executives (End) --->

   listArray:any=[];


  openVerticallyCentered(content: any,val:any) {
    console.log("valvalval",val)
   this.listArray=[]
		this.modref=this.modalService.open(content, { centered: true });
    console.log("openmodal",val)
    if(val==0){
     console.log("add",val);
     this.modalMasterList= this.masterList;
     this.modalSubMasterList= this.subMasterList;
     this.execForm.reset();
     this.getEditData = false;
     console.log("this.modalMasterList",this.modalMasterList)
 
    }else {
      this.addMoreData=val.lstPermit


      
      console.log("this.addMoreData1234", this.addMoreData)
     this.subMasterOptions=this.addMoreData.SubMasters

   this.getEditData = true;
   this.execForm.reset();
  //  this.onMasterIDChange(100)
   
 
   this.addMoreData.forEach((element:any) => {
   
    element?.SubMasters.forEach((element1:any) => {
     
      let obj={
        Master:element.Master,MasterID:element.MasterID, SubMasterID:element1.SubMaster 
      }
      this.listArray.push(obj)
    });


   });
   
// this.lstPermit=
     this.execForm.patchValue({
      name:val.Name,
      email:val.Email,
      phone:val.Phone,
      country:val.Country,
      status:val.Status,
       lstPermit:this.listArray,
      
     
       })
       console.log("this.execForm", this.execForm.value.lstPermit)
       this.execID = val.ExecID;
      
      }
	}
  closeModal(){
    this.modref.close();
  }
 
  getModule(){
    
    let obj={
      "Key":"",
      "MasterID": 0
    }
    this.api.GET_EXECH_MASTER(obj).subscribe((res:any)=>{
     if(res){
      this.masterData= res;
      console.log("this.moduledata",this.masterData);
      this.masterOptions = this.masterData.map((item: any) => ({
        id: item.MasterID,
        name: item.Master
      }));
  
      // Initialize the Sub Master dropdown options
     
      this.cd.detectChanges();
     }
     else {
      this.toastrService.error("No Data found","Error")
     }
    })
  }
  onMasterIDChange(event: any) {
    this.masterID = event; // Store the selected value (ID)
    // Update the Sub Master dropdown options based on the selected Master

    this.subMasterOptions=[]
    this.subMasterOptions = this.subMasterData
      .filter((item: any) => item.MasterID === this.masterID)
      .map((item: any) => ({
        id: item.SubMasterID,
        name: item.SubMaster
      }));
  }

  // Add a function to handle the Sub Master dropdown change event
  onSubMasterIDChange(event: any) {
    this.subMasterID = event; // Store the selected value (ID)
  }
  getSubMaster(){
    let obj = {
      "Key": "",
      "MasterID": 0,
      "SubMasterID": 0
    }
    this.api.GET_EXECH_SUB_MASTER(obj).subscribe((res:any)=>{
      if(res){
        this.subMasterData=res;
        console.log("submasterdata",this.subMasterData);
        this.subMasterOptions = this.subMasterData
        .filter((item: any) => item.MasterID === this.masterID)
        .map((item: any) => ({
          id: item.SubMasterID,
          name: item.SubMaster
        }));
        console.log("subMasterOptions", this.subMasterOptions)
        this.cd.detectChanges();
      }else {
        this.toastrService.error("No Records found", "Error!")
      }
    })
  }

  getExecutive(){
    let obj = {
      "ExecID": 0
    }
    this.shared.loader(true);
    this.api.GET_EXECUTIVE(obj).subscribe((data:any)=>{
      if(data){
        this.executiveData=data;
        this.shared.loader(false);
        this.cd.detectChanges();
      }
      else {
        this.toastrService.error("No Records found", "Error!")
      }
    })
  }

  selectedMasterChanged(master: string) {
    this.modalSubMasterList = this.subMasterData
      .filter((item:any) => item.Master === master)
      .map((item:any) => item.SubMaster);
  }

addExecutive(){

  const lstPermitArray : any=[];
  const groupedModules: { [key: number]: number[] } = {};
 
  this.execForm.get('lstPermit').value.forEach((module: any) => {
    const masterID = module.MasterID;
    const subMasterID = module.SubMasterID;
  
    if (groupedModules.hasOwnProperty(masterID)) {
      groupedModules[masterID].push(subMasterID);
    } else {
      groupedModules[masterID] = [subMasterID];
    }
  });
  
  for (const masterID in groupedModules) {
    if (groupedModules.hasOwnProperty(masterID)) {
      lstPermitArray.push({
        MasterID: +masterID, 
        SubMasters: groupedModules[+masterID],
      });
    }
  }
  let obj = {
    "Key":"",
    "Name":this.execForm.value.name,
    "Email":this.execForm.value.email,
    "Phone":this.execForm.value.phone,
    "Country":this.execForm.value.country,
    "Status":this.execForm.value.status,               
    "lstPermit":lstPermitArray,
    "TimeStampInfo":""
  }
  this.shared.loader(true);
  this.api.ADD_EXECUTVE(obj).subscribe((data:any)=>{
    if(data.Result==true){
      this.getExecutive();
      this.closeModal();
      this.toastrService.success(data.MSG_USER,"Success!")
      this.shared.loader(false)
    }
    else {
      this.toastrService.success(data.MSG_USER,"Error!")
      this.shared.loader(false)
    }
  })
}

constructOPermit(): any[] {
  const oPermitArray :any= [];

  const lstPermitArray = (<FormArray>this.execForm.get('lstPermit')) ;
  lstPermitArray.controls.forEach((moduleGroup:any= FormGroup) => {
    const masterID = moduleGroup.get('MasterID').value;
    const subMasterID = moduleGroup.get('SubMasterID').value;

    const permissions = {
      Key: "",
      MasterID: masterID,
      SubMasterID: subMasterID,
      oPermit: {
        Add: moduleGroup.get('addPermission') ? 1 : 0,
        Delete: moduleGroup.get('deletePermission') ? 1 : 0,
        Access: moduleGroup.get('accessPermission') ? 1 : 0,
        Edit: moduleGroup.get('editPermission') ? 1 : 0,
      },
    };

    oPermitArray.push(permissions);
  });

  return oPermitArray;
}
updateUserPermissions() {
 
    const executiveData = this.execForm.value;
    const oPermitData = this.constructOPermit(); // Construct oPermit data
let obj={
    "UserID" : this.execID, // Set the UserID with the actual user's ID
    "oPermit" : oPermitData
}
    

    this.shared.loader(true);
    this.api.ADD_EXEC_PERMIT(obj).subscribe((data: any) => {
      if (data.Result == true) {
        this.getExecutive();
        this.toastrService.success(data.MSG_USER, "Success!");
        this.shared.loader(false);
        this.modref.close();
      } else {
        this.toastrService.error(data.MSG_USER, "Error");
        this.shared.loader(false);
      }
    });
  
}







// updateExecutive(){
//   let obj = {
//     "UserID": this.execID,
//     "oPermit": [{
//         "Key": "",
//         "MasterID": 100,
//         "SubMasterID":1,
//         "oPermit": {
//             "Add": 0, //Enable=1,Disable=0
//             "Delete": 0, //Enable=1,Disable=0
//             "Access": 0, //Enable=1,Disable=0
//             "Edit": 0 //Enable=1,Disable=0
//         }
//     },
//     {
//         "Key": "",
//         "MasterID": 100,
//         "SubMasterID":2,
//         "oPermit": {
//             "Add": 1, //Enable=1,Disable=0
//             "Delete": 1, //Enable=1,Disable=0
//             "Access": 1, //Enable=1,Disable=0
//             "Edit": 1 //Enable=1,Disable=0
//         }
//     }]
//   }
//   this.shared.loader(true);
//   this.api.ADD_EXEC_PERMIT(obj).subscribe((res:any)=>{
//     if(res.Result==true){
//       this.getExecutive();
//       this.toastrService.success(res.MSG_USER,"Success!");
//       this.shared.loader(false);
//     }
//     else{
//       this.toastrService.error(res.MSG_USER,"Error!");
//       this.shared.loader(false);
//     }
//   })
// }
addMoreData:any=[{
  MasterID:"",
  // subMasterId:"",
  // add:"",
  // edit:""

}]
masterMdule:any=""
subModule:any=""
addMoreDataFunc(){
  this.addMoreData.push({
    MasterID:this.masterMdule ,SubMasters:[{
      SubMasterID:this.subModule
    }]
  })
}



}
