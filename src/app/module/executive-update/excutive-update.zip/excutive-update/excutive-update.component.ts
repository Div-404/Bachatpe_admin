import { Component ,OnInit,ChangeDetectorRef, OnDestroy} from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { GlobalAPIService } from './../../../service/global-api.service';
import { CookieService } from 'ngx-cookie-service';
import { SharedDataService } from 'src/app/service/shared-data.service';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';
import { FormBuilder, FormGroup, Validators ,FormArray} from '@angular/forms';
import { Router,ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-excutive-update',
  templateUrl: './excutive-update.component.html',
  styleUrls: ['./excutive-update.component.scss']
})
export class ExcutiveUpdateComponent implements OnInit, OnDestroy{
  execData: any;
  editOption: any;
  execForm:any = FormGroup;
  masterData: any;
  subMasterData: any;
  getEditData:boolean=false;
  selectedSubMasterID: any;
  selectedMasterID: any;
  executiveData: any;
  masterList: any[] = []; 
  subMasterList: any[] = [];
  modalMasterList: any=[];
  modalSubMasterList: any=[];
  masterOptions: any;
  subMasterOptions: any=[];
  masterID: any;
  subMasterID: any;
  execID: any;
  listArray:any=[];
  addMoreData:any=[];
  masterMdule:any
subModule:any
add:boolean=false;
edit:boolean=false;
delete:boolean=false;
Access:boolean=false;
vUsetData:any=[]
  exec: any;
  constructor(private modalService: NgbModal,private router: ActivatedRoute,private cd :ChangeDetectorRef,private fb: FormBuilder,private shared:SharedDataService, private cookie: CookieService, 
   private api:GlobalAPIService,public toastrService:ToastrService) {}
updataeDisplayData:any=[]
  ngOnInit(): void {
   
    
    this.getExecutive();
    this.getModule();
    this.getSubMaster();
    this.execForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', Validators.required],
      phone: ['', Validators.required],
      country: ['', Validators.required],
      status: ['', Validators.required],
      lstPermit: this.fb.array([
        this.createModuleFormGroup(),
      ]),
    });
    this.router.params.subscribe((params) => {
      this.editOption = params['id1'];
      
      this.exec = sessionStorage.getItem('execdata') ;
      this.execData = JSON.parse(this.exec)
    console.log("this.execData",this.execData);
    });

    this.listArray=[];
    if(this.editOption==0){
  
      this.modalMasterList= this.masterList;
      this.modalSubMasterList= this.subMasterList;
      this.execForm.reset();
      this.getEditData = false;
      console.log("this.modalMasterList",this.modalMasterList)
  
     }else {
      this.execData.lstPermit.forEach((element:any) => {
        console.log("vUsetData", element)
        element?.SubMasters.forEach((el:any) => {
          console.log("vUsetData123", el)  
          this.vUsetData.push({
            Master: element.Master, MasterID:  element.MasterID,

            Access: el.Access,
            Add: el.Add,
Delete: el.Delete,
Edit:  el.Edit,
SubMaster: el.SubMaster,
SubMasterID:  el.SubMasterID,

          })
        });
        
        
      });
      console.log("this.vUsetDatathis.vUsetData this.vUsetDatathis.vUsetData",this.vUsetData)
     
       this.addMoreData=this.execData.lstPermit

       this.addMoreData.forEach((element:any) => {
  
        element?.SubMasters.forEach((el:any) => {
         
          if(el.Access==0){
            el.Access=false;

          }else{
            el.Access=true;
          }
          if(el.Add==0){
            el.Add=false;

          }else{
            el.Add=true;
          }
          if(el.Edit==0){
            el.Edit=false;

          }else{
            el.Edit=true;
          }
          if(el.Delete==0){
            el.Delete=false;

          }else{
            el.Delete=true;
          }
          this.updataeDisplayData.push({Master:element.Master, MasterID:element.MasterID, SubMasters:el})
         });

       });
       
      
     console.log("this.updataeDisplayDatathis.updataeDisplayDatathis.updataeDisplayData",  this.updataeDisplayData)

     console.log("neUpdate", this.transformJSON(this.vUsetData))
    this.getEditData = true;
    this.execForm.reset();
   //  this.onMasterIDChange(100)
    
  
    this.addMoreData.forEach((element:any) => {
    
     element?.SubMasters.forEach((element1:any) => {
      
       let obj={
         Master:element.Master,MasterID:element.MasterID, SubMasterID:element1.SubMaster 
       }
       this.listArray.push(obj)
     });
 
 
    });
    

  
        console.log("this.execForm", this.execForm.value.lstPermit)
        this.execID = this.execData.ExecID;
        this.execForm.patchValue({
          name:this.execData.Name,
          email:this.execData.Email,
          phone:this.execData.Phone,
          country:this.execData.Country,
          status:this.execData.Status,
          
          
         
           })  
  }
   
}
result:any = [];
 transformJSON(inputJson: any[]): any[] {
   this.result = [];
  const subMasterMap = new Map();

  inputJson.forEach((item) => {
    const { Master, SubMaster, SubMasterID, Access, Add, Delete, Edit } = item;

    if (subMasterMap.has(Master)) {
      const subMasterEntry = subMasterMap.get(Master);

      // Check if a sub-master entry with the same SubMasterID exists, if not, add it.
      const existingSubMaster = subMasterEntry.oSubMasterPermit.find(
        (sub:any) => sub.SubMasterID === SubMasterID
      );

      if (!existingSubMaster) {
        subMasterEntry.oSubMasterPermit.push({
          SubMasterID: SubMasterID,
          SubMaster: '',
          oPermit: {
            Add: Add === 1 ? 1 : 0,
            Delete: Delete === 1 ? 1 : 0,
            Access: Access === 1 ? 1 : 0,
            Edit: Edit === 1 ? 1 : 0,
          },
        });
      }
    } else {
      const subMasterEntry = {
        MasterID: this.masterID,
        oSubMasterPermit: [
          {
            SubMasterID: SubMasterID,
            SubMaster: '123',
            oPermit: {
              Add: Add === 1 ? 1 : 0,
              Delete: Delete === 1 ? 1 : 0,
              Access: Access === 1 ? 1 : 0,
              Edit: Edit === 1 ? 1 : 0,
            },
          },
        ],
      };
      subMasterMap.set(Master, subMasterEntry);
    }
  });

  subMasterMap.forEach((subMasterEntry) => {
    this.result.push(subMasterEntry);
  });

  return this.result;
}



ngOnDestroy(): void {
  sessionStorage.removeItem('execdata')
}

  // <-- Form array for Executives (Start) --->
  createModuleFormGroup() {
    return this.fb.group({
      MasterID: ['',Validators.required],
      SubMasterID: ['',Validators.required],
     
    });
  }
  addModule() {
    const moduleGroup = this.createModuleFormGroup();
    (<FormArray>this.execForm.get('lstPermit')).push(moduleGroup);
  }
  
  removeModule(index: number) {
    (<FormArray>this.execForm.get('lstPermit')).removeAt(index);
  }

   // <-- Form array for Executives (End) --->
   getModule(){
    
    let obj={
      "Key":"",
      "MasterID": 0
    }
    this.api.GET_EXECH_MASTER(obj).subscribe((res:any)=>{
     if(res){
      this.masterData= res;
      console.log("this.moduledata",this.masterData);
      this.masterOptions = this.masterData.map((item: any) => ({
        id: item.MasterID,
        name: item.Master
      }));
  
      // Initialize the Sub Master dropdown options
     
      this.cd.detectChanges();
     }
     else {
      this.toastrService.error("No Data found","Error")
     }
    })
  }
  subMasterValue:any=[]
  MasterValue:any=[]
  onMasterIDChange(event: any) {
    console.log("event.idevent.idevent.idevent.idevent.idevent.id", event)
    this.MasterValue=event
   
    this.masterID = event.id; // Store the selected value (ID)
    // Update the Sub Master dropdown options based on the selected Master

    this.subMasterOptions=[]
    this.subMasterOptions = this.subMasterData
      .filter((item: any) => item.MasterID === this.masterID)
      .map((item: any) => ({
        id: item.SubMasterID,
        SubMaster: item.SubMaster
      }));
  }

 
  onSubMasterIDChange(event: any) {
    this.subMasterID = event; // Store the selected value (ID)
  }
  getSubMaster(){
    let obj = {
      "Key": "",
      "MasterID": 0,
      "SubMasterID": 0
    }
    this.api.GET_EXECH_SUB_MASTER(obj).subscribe((res:any)=>{
      if(res){
      
        this.subMasterData=res;
      
        console.log("submasterdata",this.subMasterData);
        this.subMasterOptions = this.subMasterData
        .filter((item: any) => item.MasterID === this.masterID)
        .map((item: any) => ({
          id: item.SubMasterID,
          SubMaster: item.SubMaster
        }));
        console.log("subMasterOptions", this.subMasterOptions)
        this.cd.detectChanges();
      }else {
        this.toastrService.error("No Records found", "Error!")
      }
    })
  }

  getExecutive(){
    let obj = {
      "ExecID": 0
    }
    this.shared.loader(true);
    this.api.GET_EXECUTIVE(obj).subscribe((data:any)=>{
      if(data){
        this.executiveData=data;
        this.shared.loader(false);
        this.cd.detectChanges();
      }
      else {
        this.toastrService.error("No Records found", "Error!")
      }
    })
  }

  selectedMasterChanged(master: string) {
    this.modalSubMasterList = this.subMasterData
      .filter((item:any) => item.Master === master)
      .map((item:any) => item.SubMaster);
  }
submoduleFilterData:any=[]


fil:any=[]
newfillData:any=[]
updatData:any=[]
addExecutive(){
 
this.newData=this.addMoreData;

console.log("000000000000000000000000000000",  this.groupByMasterID(this.vUsetData))


// console.log("dfdsfgdgfdgdfghdfghf", this.transformData(this.vUsetData))

  let obj = {
    "Key":"",
    "Name":this.execForm.value.name,
    "Email":this.execForm.value.email,
    "Phone":Number(this.execForm.value.phone),
    "Country":this.execForm.value.country,
    "Status":Number(this.execForm.value.status),               
    "lstPermit":this.groupByMasterID(this.vUsetData),
    "TimeStampInfo":""
  }
  this.shared.loader(true);
  this.api.ADD_EXECUTVE(obj).subscribe((data:any)=>{
    if(data.Result==true){
      this.getExecutive();
      
      this.toastrService.success(data.MSG_USER,"Success!")
      this.shared.loader(false)
    }
    else {
      this.toastrService.success(data.MSG_USER,"Error!")
      this.shared.loader(false)
    }
  })
}

constructOPermit(): any[] {
  const oPermitArray :any= [];

  const lstPermitArray = (<FormArray>this.execForm.get('lstPermit')) ;
  lstPermitArray.controls.forEach((moduleGroup:any= FormGroup) => {
    const masterID = moduleGroup.get('MasterID').value;
    const subMasterID = moduleGroup.get('SubMasterID').value;

    const permissions = {
      Key: "",
      MasterID: masterID,
      SubMasterID: subMasterID,
      oPermit: {
        Add: moduleGroup.get('addPermission') ? 1 : 0,
        Delete: moduleGroup.get('deletePermission') ? 1 : 0,
        Access: moduleGroup.get('accessPermission') ? 1 : 0,
        Edit: moduleGroup.get('editPermission') ? 1 : 0,
      },
    };

    oPermitArray.push(permissions);
  });

  return oPermitArray;
}
updataPermData:any=[]
updataPermData2:any=[]
updataPermData3:any=[]

data123:any=[]
data1235678:any=[]

newABCDAta:any=[]
removeDuplicateSubMasters() {

  this.data123=this.UpdateFun(this.updataeDisplayData)
  console.log("this.data123", this.data123)
  this.data123.forEach((item:any) => {
    item.SubMasters = item.SubMasters.filter((value:any, index:any, self:any) => {
      const isDuplicate = self.findIndex((subItem:any) =>
        subItem.SubMaster === value.SubMaster && subItem.SubMasterID === value.SubMasterID) !== index;
        console.log("isDuplicate", isDuplicate)
if(isDuplicate){

  item.SubMasters.splice(index, 1)

console.log("1111111111", item)
}

console.log("1111111111this.data123this.data123this.data123", this.data123)
      return !isDuplicate;
    });
  });
this.data1235678=this.data123
  console.log("this.data123this.data123this.data123this.data123this.data123this.data123", this.data123)
}


updateUserPermissions() {
 
  this.updataPermData3=[]

 
    this.updataPermData=this.UpdateFun(this.addMoreData)
    this.UpdateFun(this.updataeDisplayData)
console.log("this.updataeDisplayData", this.UpdateFun(this.updataeDisplayData))

// this.removeDuplicateSubMasters();

    this.data1235678.forEach((element:any) => {
      
       element.SubMasters.forEach((el:any) => {
       if(el.Add==false){
        el.Add=0
       }else{
        el.Add=1
       }
       if(el.Delete==false){
        el.Delete=0
       }else{
        el.Delete=1
       }
       if(el.Access==false){
        el.Access=0
       }else{
        el.Access=1
       }
       if(el.Edit==false){
        el.Edit=0
       }else{
        el.Edit=1
       }
       
        this.updataPermData2.SubMasterID=el.SubMasterID
        this.updataPermData2.push({SubMasterID:el.SubMasterID, SubMaster:el.SubMaster, oPermit:{
          "Add": el.Add,
          "Delete": el.Delete,
          "Access":el.Access,
          "Edit": el.Edit}})



     
      

       });
       this.updataPermData3.push({
        MasterID:element.MasterID,
        oSubMasterPermit:this.updataPermData2

      })
      this.updataPermData2=[]

       
    });
    this.vUsetData.forEach((element:any) => {
      if (element.Add==true){
        element.Add=1
      }else{
        element.Add=0

      }
      if (element.Edit==true){
        element.Edit=1
      }else{
        element.Edit=0

      }
      if (element.Delete==true){
        element.Delete=1
      }else{
        element.Delete=0

      }
      if (element.Access==true){
        element.Access=1
      }else{
        element.Access=0

      }
      
    });
   let dataNew=this.transformData(this.vUsetData);
let obj={
    "UserID" : this.execID, // Set the UserID with the actual user's ID
    // "oMasterPermit" :this.transformJSON(this.vUsetData)
      "oMasterPermit" :this.transformedData
}


console.log("this.updataPermData3", this.updataPermData3)
console.log("objobjobjobj", obj)
    this.shared.loader(true);
    this.api.ADD_EXEC_PERMIT(obj).subscribe((data: any) => {
      if (data.Result == true) {
        this.getExecutive();
        this.toastrService.success(data.MSG_USER, "Success!");
        this.shared.loader(false);
      
      } else {
        this.toastrService.error(data.MSG_USER, "Error");
        this.shared.loader(false);
      }
    });
  
}

addMoreDataFunc(){
 console.log("this.masterMdule", this.masterMdule)
 console.log("this.subModule", this.subModule)
  this.vUsetData.push({
    MasterID:this.masterMdule.id,
    master:this.masterMdule.name,
   
      SubMasterID: this.subMasterValue.id,
      SubMaster: this.subMasterValue.SubMaster,
      Add:this.add,
      Delete:this.delete,
      Access:this.Access,
      Edit:this.edit,
    
  })
  // this.add=false
  console.log("this.addMoreData", this.updataeDisplayData)

}

getReturn(val:any){
  let retuVal
if(val==true){
  return 1
}
else{
  return 0
}

}
getReturnVal(val:any){
 
if(val==1){
  return true
}
else{
  return false
}

}
checkedValue:any;
getCheckboxValue(val:any, i:any, val1:any, j:any){
  console.log(" this.addMoreData", val.target.checked)
  
  if(val.target.checked){
    this.checkedValue=1;
  }else{
    this.checkedValue=0

  }
    // this.addMoreData[i].SubMasters:
    this.addMoreData[i].SubMasters.forEach((element:any) => {
if(j==0){

  element.Add=this.checkedValue

}else if(j==3){
  element.Delete=this.checkedValue
}
else if(j==2){
  element.Access=this.checkedValue
}
else if(j==1){
  element.Edit=this.checkedValue
}
console.log("this.addMoreData[i].SubMasters", this.addMoreData[i].SubMasters)
// Add:this.getReturn(this.add),
// Delete:this.getReturn(this.delete),
// Access:this.getReturn(this.Access),
// Edit:this.getReturn(this.edit),
      
    });

  
console.log("val",this.addMoreData[i])

}
sModule:any;
onSubModuleChange(ev:any){
  console.log("onSubModuleChange",ev)
  this.subMasterValue=ev
// this.sModule=ev
}




newData:any=[]
filterData(val:any){
  this.fil=[]

 


  return this.newData.filter((item:any) => item.MasterID === val)

}

 filteredArray:any = [];
seen:any = {};
existingPerson:any=[]
UpdateFun(val:any){
 val.forEach((person:any) => {
  
    if (!this.seen[person.MasterID]) {
      this.seen[person.MasterID] = person;
      this.filteredArray.push(person);
    } else {
       this.existingPerson = this.filteredArray.find((p:any) => p.MasterID === person.MasterID);
      if ((this.existingPerson.SubMasters)) {
        // Merge the "key" arrays for common first names
        this.existingPerson.SubMasters ={...this.existingPerson.SubMasters, ...person.SubMasters};
      }
    }
  });
  

  return this.filteredArray

}

addUpdatFun(addMoreData: any[]) {
  const lstPermit:any = [];

  // Create an object to group SubMasters by MasterID
  const subMastersMap = new Map<number, number[]>();

  addMoreData.forEach((item) => {
    if (!subMastersMap.has(item.MasterID)) {
      subMastersMap.set(item.MasterID, []);
    }

    item.SubMasters.forEach((subMaster:any) => {
      if (subMastersMap.has(item.MasterID)) {
        subMastersMap.get(item.MasterID)?.push(subMaster.SubMasterID);
      }
    });
  });

  // Convert the grouped data back to the desired structure
  subMastersMap.forEach((subMasters, masterID) => {
    lstPermit.push({
      MasterID: masterID,
      SubMasters: subMasters,
    });
  });

  return lstPermit;
}

getCheckedValue(val:any){
if(val==0){
  return true
}else{
  return false
}
}
getId(val:any, val2:any, val3:any){

  return val3+val+val2
}
chengeData(ev:any, i:any){
if(i==0){
  this.add=ev.target.checked
}else if(i==1){
  this.edit=ev.target.checked
}
else if(i==2){
  this.delete=ev.target.checked
}
else if(i==3){
  this.Access=ev.target.checked
}




}





transformedData:any
transformData(inputJson:any) {
  // Group the original data by MasterID
  const groupedData = this.groupBy(inputJson, 'MasterID');

  // Transform the grouped data into the desired format
  this.transformedData = Object.keys(groupedData).map((masterID) => {
    return {
      MasterID: +masterID,
      oSubMasterPermit: groupedData[masterID].map((item:any) => {
        return {
          SubMasterID: item.SubMasterID,
          SubMaster: item.SubMaster,
          oPermit: {
            Add: item.Add,
            Delete: item.Delete,
            Access: item.Access,
            Edit: item.Edit
          }
        };
      })
    };
  });
}

// Helper function to group data by a specific property
groupBy(arr:any, key:any) {
  return arr.reduce(function (acc:any, obj:any) {
    const groupKey = obj[key];
    if (!acc[groupKey]) {
      acc[groupKey] = [];
    }
    acc[groupKey].push(obj);
    return acc;
  }, {});
}
groups:any={}
groupedData:any
groupByMasterID(data: any[]): any[] {
   this.groupedData = [];
   this.groups = {};

  for (const item of data) {
    const masterID = item.MasterID;
    if (!this.groups[masterID]) {
      this.groups[masterID] = {
        MasterID: masterID,
        SubMasters: [item.SubMasterID],
      };
    } else {
      this.groups[masterID].SubMasters.push(item.SubMasterID);
    }
  }

  for (const groupKey in this.groups) {
    this.groupedData.push(this.groups[groupKey]);
  }

  return this.groupedData;
}
}
