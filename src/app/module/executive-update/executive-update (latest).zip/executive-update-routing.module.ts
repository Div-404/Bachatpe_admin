import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ExecutiveComponent } from '../executive/executive/executive.component';
import { ExcutiveUpdateComponent } from './excutive-update/excutive-update.component';

const routes: Routes = [
  {path:'', component: ExcutiveUpdateComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ExecutiveUpdateRoutingModule { }
