import { Component, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { GlobalAPIService } from './../../../service/global-api.service';
import { CookieService } from 'ngx-cookie-service';
import { SharedDataService } from 'src/app/service/shared-data.service';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-excutive-update',
  templateUrl: './excutive-update.component.html',
  styleUrls: ['./excutive-update.component.scss']
})
export class ExcutiveUpdateComponent implements OnInit, OnDestroy {
  execData: any;
  editOption: any;
  execForm: any = FormGroup;
  masterData: any;
  subMasterData: any;
  getEditData: boolean = false;
  selectedSubMasterID: any;
  selectedMasterID: any;
  executiveData: any;
  masterList: any[] = [];
  subMasterList: any[] = [];
  modalMasterList: any = [];
  modalSubMasterList: any = [];
  masterOptions: any;
  subMasterOptions: any = [];
  masterID: any;
  subMasterID: any;
  execID: any;
  listArray: any = [];
  addMoreData: any = [];
  masterMdule: any
  subModule: any
  add: boolean = false;
  edit: boolean = false;
  delete: boolean = false;
  Access: boolean = false;
  vUsetData: any = []
  exec: any;
  constructor(private modalService: NgbModal, private router: ActivatedRoute, private cd: ChangeDetectorRef, private fb: FormBuilder, private shared: SharedDataService, private cookie: CookieService,
    private api: GlobalAPIService, public toastrService: ToastrService) { }
  updataeDisplayData: any = []
  ngOnInit(): void {


    this.getExecutive();
    this.getModule();
    this.getSubMaster();
    this.execForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', Validators.required],
      phone: ['', Validators.required],
      country: ['', Validators.required],
      status: ['', Validators.required],
      lstPermit: this.fb.array([
        this.createModuleFormGroup(),
      ]),
    });
    this.router.params.subscribe((params) => {
      this.editOption = params['id1'];

      this.exec = sessionStorage.getItem('execdata');
      this.execData = JSON.parse(this.exec)

    });

    this.listArray = [];
    if (this.editOption == 0) {

      this.modalMasterList = this.masterList;
      this.modalSubMasterList = this.subMasterList;
      this.execForm.reset();
      this.getEditData = false;


    } else {
      this.execData.lstPermit.forEach((element: any) => {

        element?.SubMasters.forEach((el: any) => {

          this.vUsetData.push({
            Master: element.Master, MasterID: element.MasterID,

            Access: el.Access,
            Add: el.Add,
            Delete: el.Delete,
            Edit: el.Edit,
            SubMaster: el.SubMaster,
            SubMasterID: el.SubMasterID,

          })
        });


      });


      this.addMoreData = this.execData.lstPermit

      this.addMoreData.forEach((element: any) => {

        element?.SubMasters.forEach((el: any) => {

          if (el.Access == 0) {
            el.Access = false;

          } else {
            el.Access = true;
          }
          if (el.Add == 0) {
            el.Add = false;

          } else {
            el.Add = true;
          }
          if (el.Edit == 0) {
            el.Edit = false;

          } else {
            el.Edit = true;
          }
          if (el.Delete == 0) {
            el.Delete = false;

          } else {
            el.Delete = true;
          }
          this.updataeDisplayData.push({ Master: element.Master, MasterID: element.MasterID, SubMasters: el })
        });

      });



      this.getEditData = true;
      this.execForm.reset();
 


      this.addMoreData.forEach((element: any) => {

        element?.SubMasters.forEach((element1: any) => {

          let obj = {
            Master: element.Master, MasterID: element.MasterID, SubMasterID: element1.SubMaster
          }
          this.listArray.push(obj)
        });


      });




      this.execID = this.execData.ExecID;
      this.execForm.patchValue({
        name: this.execData.Name,
        email: this.execData.Email,
        phone: this.execData.Phone,
        country: this.execData.Country,
        status: this.execData.Status,



      })
    }

  }
 
 



  ngOnDestroy(): void {
    sessionStorage.removeItem('execdata')
  }


  createModuleFormGroup() {
    return this.fb.group({
      MasterID: ['', Validators.required],
      SubMasterID: ['', Validators.required],

    });
  }
  addModule() {
    const moduleGroup = this.createModuleFormGroup();
    (<FormArray>this.execForm.get('lstPermit')).push(moduleGroup);
  }

  removeModule(index: number) {
    (<FormArray>this.execForm.get('lstPermit')).removeAt(index);
  }

 
  getModule() {

    let obj = {
      "Key": "",
      "MasterID": 0
    }
    this.api.GET_EXECH_MASTER(obj).subscribe((res: any) => {
      if (res) {
        this.masterData = res;

        this.masterOptions = this.masterData.map((item: any) => ({
          id: item.MasterID,
          name: item.Master
        }));

        

        this.cd.detectChanges();
      }
      else {
        this.toastrService.error("No Data found", "Error")
      }
    })
  }
  subMasterValue: any = []
  MasterValue: any = []
  onMasterIDChange(event: any) {

    this.MasterValue = event

    this.masterID = event.id; // Store the selected value (ID)
    // Update the Sub Master dropdown options based on the selected Master

    this.subMasterOptions = []
    this.subMasterOptions = this.subMasterData
      .filter((item: any) => item.MasterID === this.masterID)
      .map((item: any) => ({
        id: item.SubMasterID,
        SubMaster: item.SubMaster
      }));
  }


  onSubMasterIDChange(event: any) {
    this.subMasterID = event; // Store the selected value (ID)
  }
  getSubMaster() {
    let obj = {
      "Key": "",
      "MasterID": 0,
      "SubMasterID": 0
    }
    this.api.GET_EXECH_SUB_MASTER(obj).subscribe((res: any) => {
      if (res) {

        this.subMasterData = res;


        this.subMasterOptions = this.subMasterData
          .filter((item: any) => item.MasterID === this.masterID)
          .map((item: any) => ({
            id: item.SubMasterID,
            SubMaster: item.SubMaster
          }));

        this.cd.detectChanges();
      } else {
        this.toastrService.error("No Records found", "Error!")
      }
    })
  }

  getExecutive() {
    let obj = {
      "ExecID": 0
    }
    this.shared.loader(true);
    this.api.GET_EXECUTIVE(obj).subscribe((data: any) => {
      if (data) {
        this.executiveData = data;
        this.shared.loader(false);
        this.cd.detectChanges();
      }
      else {
        this.toastrService.error("No Records found", "Error!")
      }
    })
  }

  selectedMasterChanged(master: string) {
    this.modalSubMasterList = this.subMasterData
      .filter((item: any) => item.Master === master)
      .map((item: any) => item.SubMaster);
  }
  submoduleFilterData: any = []


  fil: any = []
  newfillData: any = []
  updatData: any = []
  
  
  
  addExecutive() {
 let obj = {
      "Key": "",
      "Name": this.execForm.value.name,
      "Email": this.execForm.value.email,
      "Phone": Number(this.execForm.value.phone),
      "Country": this.execForm.value.country,
      "Status": Number(this.execForm.value.status),
      "lstPermit": this.groupByMasterID(this.vUsetData),
      "TimeStampInfo": ""
    }
    this.shared.loader(true);
    this.api.ADD_EXECUTVE(obj).subscribe((data: any) => {
      if (data.Result == true) {
        this.getExecutive();

        this.toastrService.success(data.MSG_USER, "Success!")
        this.shared.loader(false)
      }
      else {
        this.toastrService.success(data.MSG_USER, "Error!")
        this.shared.loader(false)
      }
    })
  }

  
  updataPermData: any = []
  updataPermData2: any = []
  updataPermData3: any = []

  data123: any = []
  data1235678: any = []

  newABCDAta: any = []
 

  updateUserPermissions() {

    this.updataPermData3 = []


   
    this.vUsetData.forEach((element: any) => {
      if (element.Add == true) {
        element.Add = 1
      } else {
        element.Add = 0

      }
      if (element.Edit == true) {
        element.Edit = 1
      } else {
        element.Edit = 0

      }
      if (element.Delete == true) {
        element.Delete = 1
      } else {
        element.Delete = 0

      }
      if (element.Access == true) {
        element.Access = 1
      } else {
        element.Access = 0

      }

    });
    let dataNew = this.transformData(this.vUsetData);
    let obj = {
      "UserID": this.execID,

      "oMasterPermit": this.transformedData
    }



    this.shared.loader(true);
    this.api.ADD_EXEC_PERMIT(obj).subscribe((data: any) => {
      if (data.Result == true) {
        this.getExecutive();
        this.toastrService.success(data.MSG_USER, "Success!");
        this.shared.loader(false);

      } else {
        this.toastrService.error(data.MSG_USER, "Error");
        this.shared.loader(false);
      }
    });

  }

  addMoreDataFunc() {
    console.log("this.masterMdule.name",this.masterMdule)
    this.vUsetData.push({
      MasterID: this.masterMdule.id,
      Master: this.masterMdule.name,

      SubMasterID: this.subMasterValue.id,
      SubMaster: this.subMasterValue.SubMaster,
      Add: this.add,
      Delete: this.delete,
      Access: this.Access,
      Edit: this.edit,

    })



  }


  sModule: any;
  onSubModuleChange(ev: any) {

    this.subMasterValue = ev

  }




 
  chengeData(ev: any, i: any) {
    if (i == 0) {
      this.add = ev.target.checked
    } else if (i == 1) {
      this.edit = ev.target.checked
    }
    else if (i == 2) {
      this.delete = ev.target.checked
    }
    else if (i == 3) {
      this.Access = ev.target.checked
    }




  }





  transformedData: any
  transformData(inputJson: any) {
    // Group the original data by MasterID
    const groupedData = this.groupBy(inputJson, 'MasterID');

    // Transform the grouped data into the desired format
    this.transformedData = Object.keys(groupedData).map((masterID) => {
      return {
        MasterID: +masterID,
        oSubMasterPermit: groupedData[masterID].map((item: any) => {
          return {
            SubMasterID: item.SubMasterID,
            SubMaster: item.SubMaster,
            oPermit: {
              Add: item.Add,
              Delete: item.Delete,
              Access: item.Access,
              Edit: item.Edit
            }
          };
        })
      };
    });
  }

  // Helper function to group data by a specific property
  groupBy(arr: any, key: any) {
    return arr.reduce(function (acc: any, obj: any) {
      const groupKey = obj[key];
      if (!acc[groupKey]) {
        acc[groupKey] = [];
      }
      acc[groupKey].push(obj);
      return acc;
    }, {});
  }
  groups: any = {}
  groupedData: any
  groupByMasterID(data: any[]): any[] {
    this.groupedData = [];
    this.groups = {};

    for (const item of data) {
      const masterID = item.MasterID;
      if (!this.groups[masterID]) {
        this.groups[masterID] = {
          MasterID: masterID,
          SubMasters: [item.SubMasterID],
        };
      } else {
        this.groups[masterID].SubMasters.push(item.SubMasterID);
      }
    }

    for (const groupKey in this.groups) {
      this.groupedData.push(this.groups[groupKey]);
    }

    return this.groupedData;
  }
}
