import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ExecutiveUpdateRoutingModule } from './executive-update-routing.module';
import { ExcutiveUpdateComponent } from './excutive-update/excutive-update.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { NgSelectModule } from '@ng-select/ng-select';

@NgModule({
  declarations: [
    ExcutiveUpdateComponent
  ],
  imports: [
    CommonModule,
    ExecutiveUpdateRoutingModule,ReactiveFormsModule,FormsModule,NgbDropdownModule,NgSelectModule
  ]
})
export class ExecutiveUpdateModule { }
